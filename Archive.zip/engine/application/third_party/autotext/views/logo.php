<div class="logo">
    <img src="<?php echo $logo_data; ?>" />
</div>