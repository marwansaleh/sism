<section class="content">
    <!-- Your Page Content Here -->
    <?php if (isset($subview)){ $this->load->view($subview); } ?>
</section><!-- /.content -->