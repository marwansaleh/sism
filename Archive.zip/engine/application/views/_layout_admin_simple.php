<?php
$this->load->view('components/_header_admin');
$this->load->view('components/_body_admin_simple');
$this->load->view('components/_footer_admin');
