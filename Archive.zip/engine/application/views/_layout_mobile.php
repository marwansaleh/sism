<?php
$this->load->view('components/_header_mobile');
$this->load->view($subview);
$this->load->view('components/_footer_mobile');
