<?php
$this->load->view('components/_header_editor');
$this->load->view($subview);
$this->load->view('components/_footer_editor');
